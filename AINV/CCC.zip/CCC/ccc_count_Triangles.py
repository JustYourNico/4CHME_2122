#!/usr/bin/python3

from os import listdir
from os import chdir
 
    
    
class coordinates:
    def __init__( self, x, y):
        self.x=x
        self.y=y        

chdir("./Level1")
allFilesInFolder=listdir("./")
i=0
stringInFiles = ""
tempCoord = []
points = []





#Level 1
for f in allFilesInFolder:
    with open(f,'r') as x:
        stringInFiles = str(x.readline().strip('\n'))
        tempCoord=stringInFiles.split(" ")
        
        i=0
        while i<len(tempCoord):
            if i%2==0:
                points.append(coordinates(int(tempCoord[i]), int(tempCoord[i+1])))
            i+=1
        x.close()
    with open(f,'a') as x:
        if points[-2].x == points[-1].x:
            x.write("Paralell to y axis")
        if points[-2].y == points[-1].y:
            x.write("Paralell to x axis")
        x.close()



#all files are read and put into a list of points
'''
for f in allFilesInFolder:
    with open(f,'r') as x:
        stringInFiles = str(x.readline().strip('\n'))
        tempCoord=stringInFiles.split(" ")
        
        i=0
        while i<len(tempCoord):
            if i%2==0:
                points.append(coordinates(int(tempCoord[i]), int(tempCoord[i+1])))
            i+=1
        x.close()

i=0           
while i<len(points):          
    print(str(points[i].x) + " " + str(points[i].y))
    i+=1
'''